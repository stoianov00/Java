package animals;

public final class ExceptionConstants {
    public static final String EXCEPTION = "Invalid input!";

    private ExceptionConstants() {
    }
}
